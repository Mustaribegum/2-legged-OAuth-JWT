var requestorigin=context.getVariable("request.header.origin");
var origins=context.getVariable("private.originList");
var origins= origins.split(",");
var count= origins.length;
var reqorigin;
var i;

print("requestorigin: ", requestorigin);
print("origins: ", origins);

for(i=0;i < count; i++)
{
    
if (origins[i] == requestorigin)
{
reqorigin = 'true';
}

}


print("reqorigin: ", reqorigin);
if(reqorigin=='true')
{
    context.setVariable("reqoriginheader",requestorigin);
}
else
{
    context.setVariable("reqoriginheader","");
}